//
//  MXStoryboardViewController.h
//  MXSegmentedPager
//
//  Created by Maxime Epain on 25/09/2016.
//  Copyright © 2016 Maxime Epain. All rights reserved.
//

#import <MXSegmentedPager/MXSegmentedPagerController.h>

@interface MXStoryboardViewController : MXSegmentedPagerController

@end
